<?php
 
 //Mendefinisikan Konstanta
 define('HOST','localhost');
 define('USER','jeic9965_admin');
 define('PASS','[v8@x,)w#7p{');
 define('DB','jeic9965_kpr_maybank');
 
 //membuat koneksi dengan database
 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 ?>